import os

import torch.nn as nn
import torch.optim as optim
import torch
import torchvision.datasets
from IPython.core.pylabtools import figsize
from matplotlib import pyplot as plt
from torch.utils.data import DataLoader, Dataset, random_split, TensorDataset
from torchvision import transforms
from torchvision.models import resnet18, ResNet18_Weights
from sklearn.metrics import classification_report

# /Applications/Python\ 3.12/Install\ Certificates.command IN TERMINAL

if torch.cuda.is_available():
    device = torch.device("cuda")
elif torch.backends.mps.is_available():
    device = torch.device("mps")
else:
    device = torch.device("cpu")

print(device)

transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    transforms.Normalize((0.5,0.5,0.5),(0.5,0.5,0.5))
])

dataset = torchvision.datasets.ImageFolder(root='data',transform=transform)

img = dataset[0]
print(img)

train_size = int(0.7*len(dataset))
test_size = int(len(dataset)-train_size)



train_dataset, test_dataset = random_split(dataset,[train_size,test_size])


train_loader = DataLoader(train_dataset, batch_size=4, shuffle=True)
test_loader = DataLoader(test_dataset, batch_size=4, shuffle=False)


def save_plots_train(train_acc, train_loss):
    epochs = range(1, len(train_acc) + 1)

    fig, ax1 = plt.subplots(figsize=(10, 7))

    ax1.set_xlabel('Epochs')
    ax1.set_ylabel('Loss')
    ax1.plot(epochs, train_loss, color='red', linestyle='-', label='Train Loss')
    ax1.tick_params(axis='y')
    ax1.set_xticks(epochs)

    ax2 = ax1.twinx()
    ax2.set_ylabel('Accuracy')
    ax2.plot(epochs, train_acc, color='blue', linestyle='-', label='Train Accuracy')
    ax2.tick_params(axis='y')

    fig.legend(loc='center right',bbox_to_anchor=(0.905, 0.93))

    plt.title('Training Accuracy and Loss')
    plt.show()

    # Clear lists
    train_acc.clear()
    train_loss.clear()

model = resnet18()
pretrained_model = resnet18(weights='IMAGENET1K_V1')

# pretrained_model.fc = torch.nn.Identity()

criterion = nn.CrossEntropyLoss()
optimizer = optim.SGD(model.parameters(),lr=0.001,momentum=0.9)
optimizer_pretrained = optim.SGD(pretrained_model.parameters(),lr=0.001,momentum=0.9)
num_epoch = 20

train_acc = []
train_loss = []

# Function to train model
def train_model(model,criterion,optimizer,num_epoch,train_loader):
    for epoch in range(num_epoch):
        model.to(device)
        model.train()
        running_loss = 0.0
        correct = 0
        total = 0

        for inputs, labels in train_loader:
            inputs, labels = inputs.to(device),labels.to(device)
            optimizer.zero_grad()
            outputs = model(inputs)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()

            running_loss += loss.item()
            _, predicted = torch.max(outputs, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()

        train_loss.append(running_loss / len(train_loader))
        train_acc.append(100 * correct / total)

        print(f"Epoch {epoch+1}/{num_epoch}, "
              f"Train Loss: {train_loss[-1]:.4f}, Train Acc: {train_acc[-1]:.2f}%, ")

    save_plots_train(train_acc,train_loss)

def evaluate_model(model, criterion, test_loader):
    model.eval()
    model.to(device)
    running_loss = 0.0
    correct = 0
    total = 0
    all_preds = []
    all_labels = []

    with torch.no_grad():
        for inputs, labels in test_loader:
            inputs, labels = inputs.to(device), labels.to(device)
            outputs = model(inputs)
            loss = criterion(outputs, labels)

            running_loss += loss.item()
            _, predicted = torch.max(outputs, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()

            all_preds.extend(predicted.cpu().numpy())
            all_labels.extend(labels.cpu().numpy())

    avg_loss = running_loss / len(test_loader)
    accuracy = 100 * correct / total

    print(f"Test Loss: {avg_loss:.4f}, Test Accuracy: {accuracy:.2f}%")

    # Print classification report
    print("\nClassification Report:\n")
    print(classification_report(all_labels, all_preds, target_names=dataset.classes))

    return avg_loss, accuracy



train_model(model,criterion,optimizer,num_epoch,train_loader)
train_model(pretrained_model,criterion,optimizer_pretrained,num_epoch,train_loader)


print("Evaluating standard model:")
test_loss, test_accuracy = evaluate_model(model, criterion, test_loader)

print("Evaluating pretrained model:")
test_loss_pretrained, test_accuracy_pretrained = evaluate_model(pretrained_model, criterion, test_loader)