import pandas as pd
import matplotlib.pyplot as plt
import os
import seaborn as sns
from PIL import Image
import matplotlib.pyplot as plt
import numpy as np
import torch
from sklearn.model_selection import train_test_split
from torch.utils.data import DataLoader, Dataset
from torchvision import datasets
from torchvision.transforms import v2,transforms

img_path = 'Data/'
labels_cancer = ['glioma_tumor','meningioma_tumor','normal','pituitary_tumor']
file_list = []
target_list = []


for label in range(4):
    folder_path = img_path+labels_cancer[label]
    for file_name in os.listdir(folder_path):
        file_path = os.path.join(folder_path, file_name)
        file_list.append(file_path)

for file in file_list:
    if file[5] == 'g':
        target_list.append('Glioma')
    elif file[5] == 'm':
        target_list.append('Meningioma')
    elif file[5] == 'n':
        target_list.append('Normal')
    elif file[5] == 'p':
        target_list.append('Pituitary')

d = {'file path': file_list, 'target': target_list}
df_path = pd.DataFrame(d)

# Code for count of each class
# Result available in report
print(df_path['target'].value_counts())


# Code for Histogram of distribution between classes
# Result available in Report
x = df_path['target']
sns.histplot(x,shrink=.8)
plt.show()

