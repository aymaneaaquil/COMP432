import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn import svm, metrics

df = pd.read_csv('cancer.csv')
cat_column = ['GENDER','LUNG_CANCER']

le = LabelEncoder()

for column in cat_column:
    df[column] = le.fit_transform(df[column])

X = df.drop(['LUNG_CANCER'], axis=1)
y = df['LUNG_CANCER']

X_train, X_test, y_train, y_test = train_test_split(X,y,test_size=0.3)

clf = svm.SVC(kernel='linear')

clf.fit(X_train, y_train)

y_pred = clf.predict(X_test)
y_train_pred = clf.predict(X_train)

train_classification = metrics.classification_report(y_train,y_train_pred)
test_classification = metrics.classification_report(y_test,y_pred)


print(f"Classification report for TRAINING set \n {train_classification} \n \n  ")

print(f"Classification report for TEST set \n {test_classification}")






