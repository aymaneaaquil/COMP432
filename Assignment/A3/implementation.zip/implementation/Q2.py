import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch.cuda
from copy import deepcopy as dc
from sklearn.preprocessing import MinMaxScaler
import torch.nn as nn
from torch.utils.data import DataLoader, Dataset

df = pd.read_csv('AMZN.csv')

df = df[['Date','Close']]

if torch.cuda.is_available():
    device = torch.device("cuda")
elif torch.backends.mps.is_available():
    device = torch.device("mps")
else:
    device = torch.device("cpu")

df['Date'] = pd.to_datetime(df['Date'])

# plt.plot(df['Date'], df['Close'])
# plt.show()

def prepare(df, steps):
    df = dc(df)

    df.set_index('Date',inplace=True)

    for i in range(1, steps+1):
        df[f'Close (t-{i}) '] = df[ 'Close']. shift(i)

    df.dropna(inplace=True)

    return df

timeseries = prepare(df,10)
print(timeseries)
timeseries = timeseries.to_numpy()

scaler = MinMaxScaler(feature_range=(-1,1))
timeseries = scaler.fit_transform(timeseries)

X = timeseries[:, 1:]
X = dc(np.flip(X, axis=1))

y = timeseries[:,0]

X = X.reshape((-1, 10, 1))
y = y.reshape((-1,1))

X = torch.tensor(X).float()
y = torch.tensor(y).float()


class TimeSeriesDataset(Dataset):
    def __init__(self, X,y):
        self.X = X
        self.y = y
    def __len__(self):
        return len(self.X)
    def __getitem__(self, i):
        return self.X[i], self.y[i]

train_dataset = TimeSeriesDataset(X,y)

print(len(train_dataset))

train_loader = DataLoader(train_dataset, batch_size=10, shuffle=True)

class LSTM(nn.Module):
    def __init__(self):
        super(LSTM, self).__init__()
        self.lstm = nn.LSTM(input_size=1, hidden_size=4, num_layers=1, batch_first=True)
        self.linear = nn.Linear(4, 1)
    def forward(self, x):
        x, (hn, cn) = self.lstm(x)
        x = hn[-1]
        x = self.linear(x)
        return x

model =  LSTM().to(device)
print(model)

lr = 0.001
num_epochs = 25
optimizer = torch.optim.SGD(model.parameters(), lr = lr)
criterion = nn.MSELoss()

train_loss = []

for epoch in range(num_epochs):
    model.train()
    epoch_loss = 0
    for inputs, labels in train_loader:
        inputs, labels = inputs.to(device), labels.to(device)
        optimizer.zero_grad()
        outputs = model(inputs)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()
        epoch_loss += loss.item()
    train_loss.append(epoch_loss / len(train_loader))
    print(f"Epoch [{epoch+1}/{num_epochs}], Loss: {epoch_loss / len(train_loader):.4f}")

# Plotting the training loss
plt.figure(figsize=(10,5))
plt.plot(train_loss, label='Training Loss')
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.title('Training Loss Over Epochs')
plt.legend()
plt.show()


with torch.no_grad():
    predicted = model(X.to(device)).to('cpu').numpy()

plt.plot(y, label= "actual close")
plt.plot(predicted, label= "predicted close")
plt.xlabel('Day')
plt.ylabel('Close')
plt.legend()
plt.show()
