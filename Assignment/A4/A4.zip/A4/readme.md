1. Open the `Q1.ipynb` notebook in Jupyter.
2. Run the cells in the following order:
   - **IMPORTS**: Import the necessary libraries.
   - **Given function to plot color space**: Use the provided function to plot the color space.
   - **Loading Image**: Load the `bird.png` image.
   - **Plotting Original Image**: Display the original normalized image.
   - **Plotting original color space**: Plot the color space of the original image.
   - **Kmean**: Apply k-means clustering.
     - **K = 5**: Apply k-means clustering with \( K = 5 \) and plot results.
     - **K = 10**: Apply k-means clustering with \( K = 10 \) and plot results.
   - **MSE**: Compute and display the Mean Squared Error for each \( K \).
