import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt
import numpy as np
from sklearn.metrics import accuracy_score
from sklearn.metrics import mean_squared_error, r2_score
import seaborn as sns

# import data set
file_path = 'dataQ1.csv'

# turn csv to dataframe
data = pd.read_csv(file_path)

numerical_features = ['age', 'bmi', 'children', 'charges']
categorical_features = ['sex', 'smoker', 'region']

# 2x2 subplot
fig, axes = plt.subplots(2, 2, figsize=(14, 10))
# flatten array
axes = axes.flatten()
# Histogram to see distribution of each numerical feature
for i, feature in enumerate(numerical_features):
    axes[i].hist(data[feature], bins=30, edgecolor='k')
    axes[i].set_xlabel(feature.capitalize())
    axes[i].set_ylabel('Frequency')
    axes[i].set_title(f'Histogram of {feature.capitalize()}')
plt.show()

# 1x3 subplot
fig, axes = plt.subplots(1, 3, figsize=(18, 6))
# bar graph to see distribution of each categorical feature
for i, feature in enumerate(categorical_features):
    data[feature].value_counts().plot(kind='bar', ax=axes[i], edgecolor='k')
    axes[i].set_xlabel(feature.capitalize())
    axes[i].set_ylabel('Count')
    axes[i].set_title(f'Bar Plot of {feature.capitalize()}')
plt.show()

# corr matrix
plt.figure(figsize=(10, 8))
correlation_matrix = data[numerical_features].corr()
sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', linewidths=0.5)
plt.title('Correlation Matrix')
plt.show()


# HISTOGRAM --> Shows how ages relate to charge
age_category = [18,25,35,45,np.inf]
labels = ['18-25', '26-35', '36-45', '46+']
data['age_category'] = pd.cut(data['age'],age_category,labels=labels, right=False )
mean_output_per_category = data.groupby('age_category', observed=False)['charges'].mean()
plt.figure(figsize=(10, 6))
plt.bar(mean_output_per_category.index, mean_output_per_category.values, color='skyblue')
plt.xlabel('Age Category')
plt.ylabel('Mean Charge')
plt.title('Mean Charge by Age Category')
plt.show()

plt.figure(figsize=(10, 6))
plt.hexbin(data['bmi'], data['charges'], gridsize=30, cmap='Reds', mincnt=1)
cb = plt.colorbar(label='Count')
plt.xlabel('BMI')
plt.ylabel('Output')
plt.title('Hexbin Plot of BMI vs Output')
plt.show()

# transform string values to INT values
data['sex'] = data['sex'].map({'female': 0, 'male': 1})
data['smoker'] = data['smoker'].map({'no': 0, 'yes': 1})
data['region'] = data['region'].map({'northeast': 0, 'northwest': 1, 'southeast': 2, 'southwest': 3})


# turn dataframe to numpy array
data=data.to_numpy()


X = data[0:,:6]
Y = data[0:,6]



# Splitting the data 70% & 30%
X_train, X_test, Y_train,Y_test = train_test_split(X,Y,test_size=0.3,random_state=42)

# train the linear model
reg = LinearRegression()



#fit on Training set
reg.fit(X_train, Y_train)


# prediction on training set
Y_pred_train = reg.predict(X_train)
#prediction on test set
Y_pred_test = reg.predict(X_test)


# MSE and Accuracy for training set
mse_training = mean_squared_error(Y_train, Y_pred_train)
r2_training = r2_score(Y_train, Y_pred_train)

# MSE and Accuracy for test set
mse_test = mean_squared_error(Y_test, Y_pred_test)
r2_test = r2_score(Y_test, Y_pred_test)


print(f'Mean Squared Error (TRAINING set): {mse_training}')
print(f'R² Score (TRAINING set): {r2_training} \n')
print(f'Mean Squared Error (TEST set): {mse_test}')
print(f'R² Score (TEST set): {r2_test}')

