import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from sklearn.metrics import classification_report
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier

file_path = 'dataQ2.csv'

# csv to dataframe
data = pd.read_csv(file_path)


numerical_features = ['AGE', 'SMOKING', 'CHRONIC DISEASE', 'ALCOHOL CONSUMING']
categorical_features = ['GENDER', 'LUNG_CANCER']


# Convert 'LUNG_CANCER' to numerical
data['LUNG_CANCER'] = data['LUNG_CANCER'].map({'YES': 1, 'NO': 0})


# SMOKERS VS CANCER
# Aggregate data by smoking status
smoking_group_counts = data.groupby('SMOKING')['LUNG_CANCER'].sum()

# Plot
plt.figure(figsize=(10, 6))
smoking_group_counts.plot(kind='bar', color='skyblue', edgecolor='black')

# Customize the plot
plt.title('Lung Cancer Cases by Smoking Status')
plt.xlabel('Smoking Status')
plt.ylabel('Number of Lung Cancer Cases')
plt.grid(axis='y', linestyle='--', alpha=0.7)

# Add value labels on bars
for i, v in enumerate(smoking_group_counts):
    plt.text(i, v + 0.1, f"{v}", ha='center', va='bottom')

plt.show()


# 1x3 subplot
fig, axes = plt.subplots(1, 2, figsize=(18, 9))
# bar graph to see distribution of each categorical feature
for i, feature in enumerate(categorical_features):
    data[feature].value_counts().plot(kind='bar', ax=axes[i], edgecolor='k')
    axes[i].set_xlabel(feature.capitalize())
    axes[i].set_ylabel('Count')
    axes[i].set_title(f'Bar Plot of {feature.capitalize()}')
plt.show()


data['GENDER'] = data['GENDER'].map({'F': 0, 'M': 1})

data=data.to_numpy()

X = data[0:,:15]
Y = data[0:,15]

X_train, X_test, Y_train,Y_test = train_test_split(X,Y,test_size=0.3,random_state=42)

model = LogisticRegression(max_iter=1000, C=1000)
model.fit(X_train,Y_train)

# Predict on the test set
test_predictions = model.predict(X_test)

# Predict on the training set
train_predictions = model.predict(X_train)

# classification report for the training set
print("Training Set Performance:")
print(classification_report(Y_train, train_predictions))

# classification report for the test set
print("Test Set Performance:")
print(classification_report(Y_test, test_predictions))







