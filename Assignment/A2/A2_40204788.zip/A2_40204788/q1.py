import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from sklearn.preprocessing import StandardScaler
from torch.utils.data import random_split, TensorDataset, DataLoader
import matplotlib.pyplot as plt
import random
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score


# Set seed to have consistent batches
seed = 1
torch.manual_seed(seed)
np.random.seed(seed)
random.seed(seed)

# Read the CSV file
dataset = pd.read_csv("bmi.csv",delimiter=',')

# Map 'Female' to 0 and 'Male' to 1
dataset['Gender'] = dataset['Gender'].map({'Female': 0, 'Male': 1})

# Seperating X & Y
X = dataset.drop('Index',axis=1).values
y = dataset['Index'].values

# Standardize data
scaler = StandardScaler()
X = scaler.fit_transform(X)

# Turn into tensors
X = torch.tensor(X, dtype=torch.float32)
y = torch.tensor(y, dtype=torch.long)

# Split into Train/Test
dataset = TensorDataset(X,y)
train_size = int((0.7*len(dataset)))
test_size = int(len(dataset) - train_size)
train_dataset, test_dataset = random_split(dataset, [train_size, test_size])

# Creating the Neural Network
class Model(nn.Module):
    def __init__ (self):
        super().__init__()
        self.fc1 = nn.Linear(3,6)
        self.fc2 = nn.Linear(6,18)
        self.fc3 = nn.Linear(18,6)

    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        x = F.softmax(self.fc3(x),dim=1)
        return x

# Initialize the model, loss function, and optimizer
model = Model()
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

train_loss = []
train_acc = []
test_loss = []
test_acc = []

def get_data_loader(bs):
    train_loader = DataLoader(train_dataset, batch_size = bs, shuffle=True)
    test_loader = DataLoader(test_dataset, batch_size = bs, shuffle=False)
    return train_loader,test_loader


def train_model(model, optimizer, criterion, train_loader,o, num_epoch = 100):
    model.train()

    for epoch in range(num_epoch):
        epoch_loss = 0
        correct = 0
        total = 0

        for data in train_loader:
            inputs, labels = data
            optimizer.zero_grad()
            outputs = model(inputs)

            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()

            epoch_loss += loss.item()
            _, predicted = torch.max(outputs.data, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()

        train_loss.append(epoch_loss / len(train_loader))
        train_acc.append(100 * correct / total)

        # return epoch, num_epoch, epoch_loss, len(train_loader), correct, total
        if o == 1:
            print(f'Epoch {epoch+1}/{num_epoch}, Loss: {epoch_loss/len(train_loader):.4f}, Accuracy: {100*correct/total:.2f}%')


def eval_model(model, test_loader, criterion):
    model.eval()
    all_preds = []
    all_targets = []

    with torch.no_grad():
        for inputs, targets in test_loader:
            outputs = model(inputs)
            _, predicted = torch.max(outputs, 1)
            all_preds.extend(predicted.cpu().numpy())
            all_targets.extend(targets.cpu().numpy())

    accuracy = accuracy_score(all_targets, all_preds)
    precision = precision_score(all_targets, all_preds, average='weighted', zero_division=np.nan)
    recall = recall_score(all_targets, all_preds, average='weighted')
    f1 = f1_score(all_targets, all_preds, average='weighted')
    loss = criterion(outputs,targets)

    return accuracy, precision, recall, f1,loss

train_loader, test_loader = get_data_loader(40)

train_model(model,optimizer,criterion,train_loader,o=1,num_epoch=300)
fig, ax1 = plt.subplots(figsize=(12, 5))
# Plotting training loss
ax1.plot(range(300), train_loss, 'b-', label='Training Loss')
ax1.set_xlabel('Epochs')
ax1.set_ylabel('Loss', color='b')
ax1.tick_params(axis='y', labelcolor='b')
ax1.set_title('Training Loss and Accuracy Curve')

# Creating a second y-axis for accuracy
ax2 = ax1.twinx()
ax2.plot(range(300), train_acc, 'r-', label='Training Accuracy')
ax2.set_ylabel('Accuracy (%)', color='r')
ax2.tick_params(axis='y', labelcolor='r')

# Adding legends
ax1.legend(loc='upper left')
ax2.legend(loc='upper right')

plt.tight_layout()
plt.show()
acc, p, r, f,l = eval_model(model,test_loader,criterion)

print(f'\n\nTest Performance for initial training: \nAccuracy: {acc}\nPrecision: {p}\nRecall: {r}\nF1: {f}\nLoss: {l}')

param_grid = {
    "learning_rate": [0.1, 0.01, 0.001, 0.0001, 0.00001, 0.000001],
    "bach_size": [4, 8, 16, 32, 64, 128, 256]
}

best_loss = float('inf')
best_lr = 0
best_bs = 0

for lr in param_grid["learning_rate"]:
    train_loss = []
    train_acc = []

    for bs in param_grid["bach_size"]:
        train_loader, test_loader = get_data_loader(bs)

        model = Model()
        optimizer = optim.Adam(model.parameters(), lr=lr)

        train_model(model,optimizer,criterion,train_loader, o=0,num_epoch=300)

        fig, ax1 = plt.subplots(figsize=(12, 5))

        # Plotting training loss
        ax1.plot(range(300), train_loss, 'b-', label='Training Loss')
        ax1.set_xlabel('Epochs')
        ax1.set_ylabel('Loss', color='b')
        ax1.tick_params(axis='y', labelcolor='b')
        ax1.set_title(f'Training Loss and Accuracy Curve LR:{lr} ,Batch Size: {bs}')

        # Creating a second y-axis for accuracy
        ax2 = ax1.twinx()
        ax2.plot(range(300), train_acc, 'r-', label='Training Accuracy')
        ax2.set_ylabel('Accuracy (%)', color='r')
        ax2.tick_params(axis='y', labelcolor='r')

        # Adding legends
        ax1.legend(loc='upper left')
        ax2.legend(loc='upper right')

        plt.tight_layout()
        plt.show()

        accuracy, precision, recall, f1, loss = eval_model(model,test_loader,criterion)
        print(f'\n\nTest Performance for batch size: {bs} and learning rate: {lr} training: \nAccuracy: {acc}\nPrecision: {p}\nRecall: {r}\nF1: {f}\nLoss: {loss}')


        if loss < best_loss:
            best_loss, best_lr, best_bs = loss, lr, bs

        train_loss.clear()
        train_acc.clear()

print(f'\nBest combination: Learning rate = {best_lr} and Batch Size = {best_bs}')
print(f'Loss for the above combination is {best_loss}')