import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset, random_split
import pandas as pd
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt
import numpy as np
import random

# Set seed to have consistent batches
seed = 42
torch.manual_seed(seed)
np.random.seed(seed)
random.seed(seed)

# Load the dataset
data = pd.read_csv('concrete_data.csv')

# Split features and target
X = data.drop("Strength",axis=1).values
y = data["Strength"].values


# Standardize the data
scaler = StandardScaler()
X = scaler.fit_transform(X)


# Convert to PyTorch tensors
X = torch.tensor(X, dtype=torch.float32)
y = torch.tensor(y, dtype=torch.float32).view(-1, 1)

# Split into train and test sets (70% train, 30% test)
dataset = TensorDataset(X, y)
train_size = int(0.7 * len(dataset))
test_size = len(dataset) - train_size
train_dataset, test_dataset = random_split(dataset, [train_size, test_size])

train_loader = DataLoader(train_dataset, batch_size=16, shuffle=True)
test_loader = DataLoader(test_dataset, batch_size=16, shuffle=False)

class Model(nn.Module):
    def __init__(self):
        super(Model, self).__init__()
        self.fc1 = nn.Linear(8, 256)
        self.fc2 = nn.Linear(256, 128)
        self.fc3 = nn.Linear(128, 64)
        self.fc4 = nn.Linear(64, 32)
        self.fc5 = nn.Linear(32, 1)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        x = torch.relu(self.fc3(x))
        x = torch.relu(self.fc4(x))
        x = self.fc5(x)
        return x

# Initialize Model, Criterion and Optimizer
model = Model()
criterion = nn.MSELoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

train_loss_mse = []

def get_data_loader(bs):
    train_loader = DataLoader(train_dataset, batch_size=bs, shuffle=True)
    test_loader = DataLoader(test_dataset, batch_size=bs, shuffle=False)
    return train_loader, test_loader

def train_model(model, optimizer, criterion, train_loader, o, num_epoch=100):
    model.train()
    epoch_losses = []
    batch_losses = []

    for epoch in range(num_epoch):
        epoch_loss = 0

        for data in train_loader:
            #Forward Pass
            inputs, labels = data
            outputs = model(inputs)
            loss = criterion(outputs, labels)

            #Backward pass
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            batch_losses.append(loss.item())
            epoch_loss += loss.item()

        avg_epoch_loss = epoch_loss / len(train_loader)
        epoch_losses.append(avg_epoch_loss)

        if o == 1:
            print(f'Epoch {epoch+1}/{num_epoch}, Loss: {avg_epoch_loss:.4f}.')

    return epoch_losses, batch_losses

def eval_model(model, test_loader, criterion):
    model.eval()
    test_preds = []
    test_targets = []

    with torch.no_grad():
        for inputs, targets in test_loader:
            outputs = model(inputs)
            test_preds.append(outputs)
            test_targets.append(targets)

    test_preds = torch.cat(test_preds).numpy()
    test_targets = torch.cat(test_targets).numpy()
    test_preds_tensor = torch.tensor(test_preds, dtype=torch.float32)
    test_targets_tensor = torch.tensor(test_targets, dtype=torch.float32)

    mse = nn.MSELoss()
    mae = nn.L1Loss()

    mse_test_loss = mse(test_preds_tensor, test_targets_tensor)
    mae_test_loss = mae(test_preds_tensor, test_targets_tensor)

    mse = mse_test_loss.item()
    mae = mae_test_loss.item()
    return mse, mae


def plot_losses(train_loss_mse, batch_loss_mse, config=None):
    plt.figure(figsize=(12, 10))

    if config:
        lr, bs = config
        title_1 = f'Loss vs Epoch (MSE); Learning Rate: {lr}, Batch Size: {bs}'
        title_2 = f'Loss vs Batch (MSE); Learning Rate: {lr}, Batch Size: {bs}'

    # First subplot: Loss vs Epochs (MSE)
    plt.subplot(2, 1, 1)
    plt.plot(range(100), train_loss_mse, label='Training Loss')
    plt.xlabel('Epochs')
    plt.ylabel('Loss')
    plt.title(title_1)
    plt.legend()

    # Second subplot: Loss vs Batch (MSE)
    plt.subplot(2, 1, 2)
    plt.plot(range(len(batch_loss_mse)), batch_loss_mse, label='Training Loss')
    plt.xlabel('Training Steps')
    plt.ylabel('Loss')
    plt.title(title_2)
    plt.legend()

    # Display the combined figure
    plt.tight_layout()
    plt.show()

train_loader, test_loader = get_data_loader(64)

# Initial Train
train_loss_mse, batch_loss_mse = train_model(model, optimizer, criterion, train_loader, o=1, num_epoch=100)

# Training Curve
plot_losses(train_loss_mse, batch_loss_mse, (0.001, 16))

# Evaluate Model on test set
mse, mae = eval_model(model, test_loader, criterion)
print(f'MSE for test set: {mse}')
print(f'MAE for test set: {mae}')


count = 0
# Fine Tune Model
param_grid = {
    "learning_rate": [0.1, 0.01, 0.001, 0.0001],
    "batch_size": [8, 16, 32, 64]
}

best_loss = float('inf')
best_lr = 0
best_bs = 0

for lr in param_grid["learning_rate"]:
    for bs in param_grid["batch_size"]:
        model = Model()
        optimizer = torch.optim.Adam(model.parameters(), lr=lr)
        train_loader, test_loader = get_data_loader(bs)

        train_loss_mse, batch_loss_mse = train_model(model, optimizer, criterion, train_loader, o=0, num_epoch=100)
        count += 1
        # Training Curve
        config = (lr, bs)
        plot_losses(train_loss_mse, batch_loss_mse, config)

        mse, mae = eval_model(model, test_loader, criterion)
        loss = mse

        print(f'Testing Performance for batch size: {bs} and learning Rate: {lr}:\n MSE: {mse}\n MAE: {mae}')

        if loss < best_loss:
            best_loss, best_lr, best_bs = loss, lr, bs

print(f'\n \nBest combination: Learning rate = {best_lr} and Batch Size = {best_bs}')
print(f'MSE for the above combination is {best_loss}')
